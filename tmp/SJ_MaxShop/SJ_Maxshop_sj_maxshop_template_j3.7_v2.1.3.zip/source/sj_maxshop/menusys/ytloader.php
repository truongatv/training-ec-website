<?php
/**
 * YouTech utilities script file.
 * 
 * @author The YouTech JSC
 * @package menusys
 * @filesource ytloader.php
 * @license Copyright (c) 2011 The YouTech JSC. All Rights Reserved.
 * @tutorial http://www.smartaddons.com
 */

include_once 'ytdebuger.php';
include_once 'ytobject.php';
include_once 'ytparam.php';
include_once 'ytmenu.php';
include_once 'ytmenubase.php';
