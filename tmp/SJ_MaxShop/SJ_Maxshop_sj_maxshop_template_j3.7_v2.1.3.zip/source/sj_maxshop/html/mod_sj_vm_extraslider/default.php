<?php
/**
 * @package Sj Vm Extra Slider
 * @version 3.0.0
 * @license http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 * @copyright (c) 2014 YouTech Company. All Rights Reserved.
 * @author YouTech Company http://www.smartaddons.com
 *
 */

defined('_JEXEC') or die;

if (!empty($list)) {
    JHtml::stylesheet('modules/' . $module->module . '/assets/css/style.css');
    JHtml::stylesheet('modules/' . $module->module . '/assets/css/css3.css');
    if (!defined('SMART_JQUERY') && $params->get('include_jquery', 0) == "1") {
        JHtml::script('modules/' . $module->module . '/assets/js/jquery-1.8.2.min.js');
        JHtml::script('modules/' . $module->module . '/assets/js/jquery-noconflict.js');
        define('SMART_JQUERY', 1);
    }

    JHtml::script('modules/' . $module->module . '/assets/js/jcarousel.js');
    JHtml::script('modules/' . $module->module . '/assets/js/jquery.cj-swipe.js');


    ImageHelper::setDefault($params);
    $options = $params->toObject();
    $count_item = count($list);
    $item_of_page = $params->get('items_page', 6);
    $item_of_page = ($item_of_page <= 0 || $item_of_page > $count_item) ? 1 : $item_of_page;
    $pags = (int)ceil($count_item / $item_of_page);
    $tag_id = 'sj_extraslider_' . rand() . time();

    $play = $params->get('play', 1);
    if (!$play) {
        $interval = 0;
    } else {
        $interval = $params->get('interval', 5000);
    }
    $currency = CurrencyDisplay::getInstance();
    $nb_column1 = ($params->get('nb-column1', 6) >= $item_of_page) ? $item_of_page : $params->get('nb-column1', 6);
    $nb_column2 = ($params->get('nb-column2', 4) >= $item_of_page) ? $item_of_page : $params->get('nb-column2', 4);
    $nb_column3 = ($params->get('nb-column3', 2) >= $item_of_page) ? $item_of_page : $params->get('nb-column3', 2);
    $nb_column4 = ($params->get('nb-column4', 1) >= $item_of_page) ? $item_of_page : $params->get('nb-column4', 1);
    ?>
    <?php $class_respl = 'extra-resp01-' . $nb_column1 . ' extra-resp02-' . $nb_column2 . ' extra-resp03-' . $nb_column3 . ' extra-resp04-' . $nb_column4; ?>
    <!--[if lt IE 9]>
    <div id="<?php echo $tag_id;?>"
         class="sj-extraslider msie lt-ie9 <?php if( $options->effect == 'slide' ){ echo $options->effect;}?>  <?php echo $class_respl; ?>"
         data-interval="<?php echo $interval; ?>" data-pause="<?php echo $params->get('pause_hover'); ?>"><![endif]-->
    <!--[if IE 9]>
    <div id="<?php echo $tag_id;?>"
         class="sj-extraslider msie <?php if( $options->effect == 'slide' ){ echo $options->effect;}?>  <?php echo $class_respl; ?>"
         data-interval="<?php echo $interval; ?>" data-pause="<?php echo $params->get('pause_hover'); ?>"><![endif]-->
    <!--[if gt IE 9]><!-->
    <div id="<?php echo $tag_id; ?>" class="sj-extraslider <?php if ($options->effect == 'slide') {
        echo $options->effect;
    } ?>  <?php echo $class_respl; ?>" data-interval="<?php echo $interval; ?>"
         data-pause="<?php echo $params->get('pause_hover'); ?>"><!--<![endif]-->
        <?php if (!empty($options->pretext)) { ?>
            <div class="pre-text"><?php echo $options->pretext; ?></div>
        <?php } ?>
        <?php if ($options->title_slider_display == 1) { ?>
            <div class="heading-title"><h3 class="heading-title-inner"><?php echo $options->title_slider; ?></h3></div><!--end heading-title-->
        <?php
        }
        if ($pags > 1) {
            ?>
            <div class="extraslider-control  <?php if ($options->button_page == 'under') {
                echo 'button-type2';
            } ?>">
                <a class="button-prev" href="<?php echo '#' . $tag_id; ?>" data-jslide="prev"><i class="fa fa-angle-left"></i></a>
                <?php if ($options->button_page == 'top') { ?>
                    <!-- ul class="nav-page">
                        <?php $j = 0;
                        $page = 0;
                        for ($i = 0; $i < $pags; $i++) {
                            $j++;
                            $active_class = $page == 0 ? " active" : "";
                            $page++;?>
                            <li class="page">
                                <a class="button-page <?php if ($page == 1) {
                                    echo 'sel';
                                } ?>" href="<?php echo '#' . $tag_id; ?>" data-jslide="<?php echo $page - 1; ?>"></a>
                            </li>
                        <?php } ?>
                    </ul -->
                <?php } ?>
                <a class="button-next" href="<?php echo '#' . $tag_id; ?>" data-jslide="next"><i class="fa fa-angle-right"></i></a>
            </div>
        <?php } ?>
        <div class="extraslider-inner">
            <?php
            for ($i = 0; $i < $pags; $i++) {
                $count = 0;
                $i = 0;
                $j = 0;
                foreach ($list as $item) {
                    $count++;
                    $i++;
                    if ($j == $item_of_page) {
                        $j = 0;
                    }
                    $j++;
                    ?>
                    <?php if ($count % $item_of_page == 1 || $item_of_page == 1) { ?>
                        <div class="item <?php if ($i == 1) {
                            echo "active";
                        } ?>">
                        <div class="line">
                    <?php } ?>
                    <div class="item-wrap <?php echo $options->theme; ?>">
                        <div class="item-wrap-inner">
                            <?php $img = VmExtrasliderHelper::getVmImage($item, $params);
                            if ($img) {
                                ?>
                                <div class="item-image">
                                    <a href="<?php echo $item->link; ?>"
                                       title="<?php echo $item->title ?>" <?php echo VmExtrasliderHelper::parseTarget($params->get('item_link_target')); ?>>
                                        <?php echo VmExtrasliderHelper::imageTag($img); ?>
                                    </a>
                                </div>
                            <?php } ?>

                            <?php if ($options->item_title_display == 1 || $options->item_desc_display == 1 || $options->item_readmore_display == 1 || $options->item_addtocart_display == 1) { ?>
                                <div class="item-info">
                                    <div class="product-review">
                                        <?php
                                            $maxrating = VmConfig::get('vm_maximum_rating_scale', 5);
                                            if (empty($item->rating)) {
                                            ?>
                                                <div class="ratingbox dummy" title="<?php echo vmText::_('COM_VIRTUEMART_UNRATED'); ?>" ></div>
                                            <?php
                                            } else {
                                                $ratingwidth = $item->rating * 14;
                                          ?>

                                            <div title=" <?php echo (vmText::_("COM_VIRTUEMART_RATING_TITLE") . round($item->rating) . '/' . $maxrating) ?>" class="ratingbox" >
                                                <div class="stars-orange" style="width:<?php echo $ratingwidth.'px'; ?>"></div>
                                            </div>
                                            <?php
                                            }
                                        ?>							
                                     </div>
                                    <?php if ($options->item_title_display == 1) { ?>
                                        <div class="item-title">
                                            <a href="<?php echo $item->link; ?>"
                                               title="<?php echo $item->title ?>" <?php echo VmExtrasliderHelper::parseTarget($params->get('item_link_target')); ?>>
                                                <?php echo VmExtrasliderHelper::truncate($item->title, $params->get('item_title_max_characs', 25)); ?>
                                            </a>
                                        </div>
                                    <?php } ?>

                                    <?php if ($params->get('item_addtocart_display', 1)) {
                                        $_item['product'] = $item; ?>
                                        <div class="item-addtocart">
                                            <?php echo shopFunctionsF::renderVmSubLayout('addtocart', $_item); ?>
                                        </div>
                                    <?php } ?>

                                    <?php if ($options->item_desc_display == 1 && !empty($item->_description) || $params->get('item_price_display', 1) || $options->item_readmore_display == 1) { ?>
                                        <div class="item-content">

                                            <?php if ($options->item_desc_display == 1) { ?>
                                                <div class="item-description">
                                                    <?php echo $item->_description; ?>
                                                </div>
                                            <?php } ?>

                                            <?php if ((int)$params->get('item_price_display', 1)) { ?>
                                                <div class="item-price">
                                                    <?php
                                                        if (!empty($item->prices['salesPrice'])) {
                                                            echo $currency->createPriceDiv('salesPrice', JText::_("Price: "), $item->prices, false, false, 1.0, true);
                                                            //var_dump($item);die;
                                                        }
                                                        if (!empty($item->prices['discountAmount'])) {
                                                            $currency = CurrencyDisplay::getInstance();
                                                            echo $currency->createPriceDiv('discountAmount', JText::_("Price: "), $item->prices, false, false, 1.0, true);
                                                        } ?>
                                                </div>
                                            <?php } ?>

                                            <?php if ($options->item_readmore_display == 1) { ?>
                                                <div class="item-readmore">
                                                    <a href="<?php echo $item->link; ?>"
                                                       title="<?php echo $item->title ?>" <?php echo VmExtrasliderHelper::parseTarget($params->get('item_link_target')); ?>>
                                                        <?php echo $options->item_readmore_text; ?>
                                                    </a>
                                                </div>
                                            <?php } ?>

                                        </div>
                                    <?php } ?>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <?php
                    $clear = 'clr1';
                    if ($j % 2 == 0) $clear .= ' clr2';
                    if ($j % 3 == 0) $clear .= ' clr3';
                    if ($j % 4 == 0) $clear .= ' clr4';
                    if ($j % 5 == 0) $clear .= ' clr5';
                    if ($j % 6 == 0) $clear .= ' clr6';
                    ?>
                    <div class="<?php echo $clear; ?>"></div>
                    <?php if (($count % $item_of_page == 0 || $count == $count_item)) { ?>
                        </div><!--line-->
                        </div><!--end item-->
                    <?php } ?>
                <?php } ?>
            <?php } ?>
        </div>
        <!--end extraslider-inner -->
        <?php if ($options->button_page == 'under') { ?>
            <ul class="nav-page nav-under">
                <?php $j = 0;
                $page = 0;
                for ($i = 0; $i < $pags; $i++) {
                    $j++;
                    $active_class = $page == 0 ? " active" : "";
                    $page++;
                    ?>
                    <li class="page">
                        <a class="button-page <?php if ($page == 1) {
                            echo 'sel';
                        } ?>" href="<?php echo '#' . $tag_id; ?>" data-jslide="<?php echo $page - 1; ?>"></a>
                    </li>
                <?php } ?>
            </ul>
        <?php } ?>
        <?php if (!empty($options->posttext)) { ?>
            <div class="post-text"><?php echo $options->posttext; ?></div>
        <?php } ?>
    </div>
    <script>
        //<![CDATA[
        jQuery(document).ready(function ($) {
            ;
            (function (element) {
                var $element = $(element);

                <?php if ($params->get('item_addtocart_display', 1) == 1 && VmConfig::get('addtocart_popup') == 1) { ?>
                if (typeof  Virtuemart !== 'undefined') {
                    Virtuemart.addtocart_popup = "<?php echo VmConfig::get('addtocart_popup'); ?>";
                    usefancy = "<?php echo VmConfig::get('usefancy');?>";
                    vmLang = "<?php echo VmConfig::get('vmLang') != ''?VmConfig::get('vmLang'):"";?>";
                    window.vmSiteurl = "<?php echo JUri::base();?>";
                }
                <?php } ?>

                $element.each(function () {
                    var $this = $(this), options = options = !$this.data('modal') && $.extend({}, $this.data());
                    $this.jcarousel(options);
                    $this.bind('jslide', function (e) {
                        var index = $(this).find(e.relatedTarget).index();
                        // process for nav
                        $('[data-jslide]').each(function () {
                            var $nav = $(this), $navData = $nav.data(), href, $target = $($nav.attr('data-target') || (href = $nav.attr('href')) && href.replace(/.*(?=#[^\s]+$)/, ''));
                            if (!$target.is($this)) return;
                            if (typeof $navData.jslide == 'number' && $navData.jslide == index) {
                                $nav.addClass('sel');
                            } else {
                                $nav.removeClass('sel');
                            }
                        });
                    });
                    <?php
                    if($params->get('swipe_enable') == 1) {	?>
                    $this.touchSwipeLeft(function () {
                            $this.jcarousel('next');
                        }
                    );
                    $this.touchSwipeRight(function () {
                            $this.jcarousel('prev');
                        }
                    );
                    <?php } ?>
                    return;
                });

            })('#<?php echo $tag_id; ?>');
        });
        //]]>
    </script>

<?php
} else {
    echo JText::_('Has no item to show!');
} ?>



